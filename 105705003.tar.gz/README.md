# scrabble


Krylow-Bellman Boosting

Use least squares temporal difference using the feature set

how do we expand the feature set?
Boosting style successive refitting of Bellman error.

interleave the two

Kyrov-Bellman Boosting saves sample size dramatically.

impossible to collect new data under different policies.

adverse selection: people gaming the system.